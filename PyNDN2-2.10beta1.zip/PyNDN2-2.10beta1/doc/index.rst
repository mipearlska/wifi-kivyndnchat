.. PyNDN documentation master file, created by
   sphinx-quickstart on Tue Mar  5 15:11:41 2019.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to PyNDN's documentation!
=================================

.. toctree::
   :maxdepth: 4
   :caption: Contents:

   pyndn


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
