#!/bin/sh
sphinx-apidoc -f -F -H PyNDN -A 'Regents of the University of California' -V 2.1 -o . ../python ../python/pyndn/contrib
